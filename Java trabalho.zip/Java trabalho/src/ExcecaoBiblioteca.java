public class ExcecaoBiblioteca extends Exception {
    public ExcecaoBiblioteca(String mensagem) {
        super(mensagem);
    }
}
