import java.util.*;

public class Cliente extends Pessoa {
    private List<Emprestimo> historicoEmprestimos;

    public Cliente(String nome, String cpf) {
        super(nome, cpf);
        this.historicoEmprestimos = new ArrayList<>();
    }

    public List<Emprestimo> getHistoricoEmprestimos() {
        return historicoEmprestimos;
    }

    public void setHistoricoEmprestimos(List<Emprestimo> historicoEmprestimos) {
        this.historicoEmprestimos = historicoEmprestimos;
    }
}
