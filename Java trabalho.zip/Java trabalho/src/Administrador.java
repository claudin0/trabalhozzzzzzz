public class Administrador extends Pessoa {
    public Administrador(String nome, String cpf) {
        super(nome, cpf);
    }
}
