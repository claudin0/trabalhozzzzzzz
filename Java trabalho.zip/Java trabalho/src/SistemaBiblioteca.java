import java.util.Scanner;
import java.util.Date;

public class SistemaBiblioteca {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = null;

        try {
            DataPersistencia persistencia = new PersistenciaTXT();
            biblioteca = new Biblioteca(persistencia);
        } catch (ExcecaoBiblioteca e) {
            System.out.println("Erro ao carregar dados: " + e.getMessage());
        }

        while (true) {
            System.out.println("=== Menu Biblioteca ===");
            System.out.println("1. Adicionar Livro");
            System.out.println("2. Adicionar Usuário");
            System.out.println("3. Realizar Empréstimo");
            System.out.println("4. Listar Livros");
            System.out.println("5. Listar Usuários");
            System.out.println("6. Listar Empréstimos");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();  

            switch (opcao) {
                case 1:
                    adicionarLivro(scanner, biblioteca);
                    break;
                case 2:
                    adicionarUsuario(scanner, biblioteca);
                    break;
                case 3:
                    realizarEmprestimo(scanner, biblioteca);
                    break;
                case 4:
                    listarLivros(biblioteca);
                    break;
                case 5:
                    listarUsuarios(biblioteca);
                    break;
                case 6:
                    listarEmprestimos(biblioteca);
                    break;
                case 7:
                    System.out.println("Saindo...");
                    salvarDados(biblioteca);
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static void adicionarLivro(Scanner scanner, Biblioteca biblioteca) {
        System.out.print("Digite o título do livro: ");
        String titulo = scanner.nextLine();
        Livro livro = new Livro(titulo) {};
        biblioteca.adicionarLivro(livro);
        System.out.println("Livro adicionado com sucesso!");
    }

    private static void adicionarUsuario(Scanner scanner, Biblioteca biblioteca) {
        System.out.print("Digite o nome do usuário: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o endereço do usuário: ");
        String endereco = scanner.nextLine();
        Usuario usuario = new Usuario(nome, endereco);
        biblioteca.adicionarUsuario(usuario);
        System.out.println("Usuário adicionado com sucesso!");
    }

    private static void realizarEmprestimo(Scanner scanner, Biblioteca biblioteca) {
        System.out.print("Digite o nome do usuário: ");
        String nomeUsuario = scanner.nextLine();
        Usuario usuario = biblioteca.getUsuarios().stream()
                                   .filter(u -> u.getNome().equals(nomeUsuario))
                                   .findFirst()
                                   .orElse(null);

        if (usuario == null) {
            System.out.println("Usuário não encontrado.");
            return;
        }

        System.out.print("Digite o título do livro: ");
        String tituloLivro = scanner.nextLine();
        Livro livro = biblioteca.getLivros().stream()
                                .filter(l -> l.getTitulo().equals(tituloLivro))
                                .findFirst()
                                .orElse(null);

        if (livro == null) {
            System.out.println("Livro não encontrado.");
            return;
        }

        Emprestimo emprestimo = new Emprestimo(usuario, new Date());
        ItemEmprestimo itemEmprestimo = new ItemEmprestimo(livro, new Date());
        emprestimo.getItensEmprestados().add(itemEmprestimo);
        biblioteca.realizarEmprestimo(emprestimo);
        System.out.println("Empréstimo realizado com sucesso!");
    }

    private static void listarLivros(Biblioteca biblioteca) {
        System.out.println("=== Lista de Livros ===");
        for (Livro livro : biblioteca.getLivros()) {
            System.out.println("Título: " + livro.getTitulo());
        }
    }

    private static void listarUsuarios(Biblioteca biblioteca) {
        System.out.println("=== Lista de Usuários ===");
        for (Usuario usuario : biblioteca.getUsuarios()) {
            System.out.println("Nome: " + usuario.getNome() + ", Endereço: " + usuario.getEndereco());
        }
    }

    private static void listarEmprestimos(Biblioteca biblioteca) {
        System.out.println("=== Lista de Empréstimos ===");
        for (Emprestimo emprestimo : biblioteca.getEmprestimos()) {
            System.out.println("Usuário: " + emprestimo.getUsuario().getNome() + ", Data do Empréstimo: " + emprestimo.getDataEmprestimo());
            for (ItemEmprestimo item : emprestimo.getItensEmprestados()) {
                System.out.println("  Livro: " + item.getLivro().getTitulo() + ", Data de Devolução: " + item.getDataDevolucao());
            }
        }
    }

    private static void salvarDados(Biblioteca biblioteca) {
        try {
            biblioteca.getPersistencia().salvarDados(biblioteca.getLivros(), biblioteca.getUsuarios(), biblioteca.getEmprestimos());
            System.out.println("Dados salvos com sucesso!");
        } catch (ExcecaoBiblioteca e) {
            System.out.println("Erro ao salvar dados: " + e.getMessage());
        }
    }
}
