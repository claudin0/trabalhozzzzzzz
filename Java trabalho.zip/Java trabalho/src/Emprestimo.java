import java.util.*;

public class Emprestimo {
    private Usuario usuario;
    private List<ItemEmprestimo> itensEmprestados;
    private Date dataEmprestimo;
    private Date dataDevolucao;

    public Emprestimo(Usuario usuario, Date dataEmprestimo) {
        this.usuario = usuario;
        this.dataEmprestimo = dataEmprestimo;
        this.itensEmprestados = new ArrayList<>();
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<ItemEmprestimo> getItensEmprestados() {
        return itensEmprestados;
    }

    public void setItensEmprestados(List<ItemEmprestimo> itensEmprestados) {
        this.itensEmprestados = itensEmprestados;
    }

    public Date getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(Date dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
}
