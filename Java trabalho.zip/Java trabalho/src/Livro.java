import java.util.*;

public abstract class Livro {
    private String titulo;
    private List<Autor> autores;
    private List<Categoria> categorias;

    public Livro(String titulo) {
        this.titulo = titulo;
        this.autores = new ArrayList<>();
        this.categorias = new ArrayList<>();
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<Autor> getAutores() {
        return autores;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
}
