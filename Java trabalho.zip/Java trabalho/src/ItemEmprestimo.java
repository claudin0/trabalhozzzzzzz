import java.util.*;

public class ItemEmprestimo {
    private Livro livro;
    private Date dataDevolucao;

    public ItemEmprestimo(Livro livro, Date dataDevolucao) {
        this.livro = livro;
        this.dataDevolucao = dataDevolucao;
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
}
