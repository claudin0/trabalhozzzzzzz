import java.util.*;

public interface DataPersistencia {
    void salvarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) throws ExcecaoBiblioteca;
    void carregarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) throws ExcecaoBiblioteca;
}
